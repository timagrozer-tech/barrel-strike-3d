# Barrel Strike 3D v1.1 — Weapon Visuals & Animation

- Added detailed modular 3D weapon geometry: upper receiver, handguard, glowing vents, grip, rail and barrel ribs.
- Added recoil animation when firing and procedural arm movement while running.
- Improved the weapon preview scene with colored fill light.
- Preserved the existing weapon shop, hybrid fusion, equipment, biomes and Android build workflow.

These are procedural meshes, not externally sourced photorealistic GLB models. APK compilation is not verified.
