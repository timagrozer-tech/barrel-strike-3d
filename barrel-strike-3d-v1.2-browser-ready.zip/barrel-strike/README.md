# Barrel Strike 3D — Browser Edition v1.2

3D браузерная игра на TypeScript, Three.js и Vite. Включены магазин улучшений, оружие, Merge, гибридная кузница с 10 уровня, 3D конструктор, биомы, эффекты, локальное сохранение.

## Опубликовать игру

См. [DEPLOY-GITHUB-PAGES.md](DEPLOY-GITHUB-PAGES.md). В `.github/workflows/pages.yml` настроена публикация GitHub Pages при пуше в ветку `main` или вручную.

## Локально

```bash
npm install
npm run dev
```

## Android

`.github/workflows/android.yml` — облачная сборка отладочного APK. Не проверена в этой среде из-за недоступности npm registry.
