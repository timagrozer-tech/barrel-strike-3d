import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
const $=(id:string)=>document.getElementById(id)!;
const saved=(()=>{try{return JSON.parse(localStorage.getItem('barrel-save')||'{}')}catch{return {}}})();
const state={coins:saved.coins||0,score:saved.score||0,stage:saved.stage||1,damage:saved.damage||1,rate:saved.rate||1,income:saved.income||1,hp:5,combo:0,kills:0,crit:saved.crit||0,multishot:saved.multishot||0,armor:saved.armor||0,luck:saved.luck||0};
// Weapon inventory persists separately so older saves remain compatible.
type Weapon={id:number;tier:number;fusion?:{a:number;b:number;name:string;power:number;crit:number;rate:number};custom?:{barrel:number;stock:number;scope:number;glow:number}};
const FUSION_UNLOCK_LEVEL=10;
function characterLevel(){return Math.max(1,Math.floor(Math.sqrt(Math.max(0,state.score)/250))+1)}
function fusionCost(a:Weapon,b:Weapon){return Math.round(350*(1+a.tier+b.tier)*Math.pow(1.25,Math.max(a.tier,b.tier)))}
function customName(a:number,b:number){return `${weaponNames[a]} × ${weaponNames[b]}`}
const weaponNames=['Пистолет','ПП «Искра»','Штурмовая винтовка','Пулемёт «Гром»','Плазменный бластер','Легендарный излучатель'];
const weaponColors=[0x889aab,0x4dd9aa,0x48a9ff,0xa576ff,0xffbc58,0xff6589];
const weaponSave=(()=>{try{return JSON.parse(localStorage.getItem('barrel-weapons-v1')||'{}')}catch{return {}}})();
let inventory:Weapon[]=Array.isArray(weaponSave.inventory)?weaponSave.inventory.filter((w:any)=>Number.isInteger(w.id)&&Number.isInteger(w.tier)&&w.tier>=0&&w.tier<6&&(!w.fusion||(typeof w.fusion.name==='string'&&Number.isFinite(w.fusion.power)&&Number.isFinite(w.fusion.crit)&&Number.isFinite(w.fusion.rate)))).slice(0,24):[{id:1,tier:0}];
let nextWeaponId=Math.max(1,...inventory.map(w=>w.id))+1;
let equippedId=inventory.some(w=>w.id===weaponSave.equippedId)?weaponSave.equippedId:inventory[0]?.id;
let weaponCrates=Number.isInteger(weaponSave.crates)?weaponSave.crates:0;
function activeWeapon(){return inventory.find(w=>w.id===equippedId)||inventory[0]}
function weaponMultiplier(){const w=activeWeapon();const base=w?.fusion?.power||Math.pow(1.7,w?.tier||0);return base*([1,1.12,1.26][w?.custom?.barrel||0])}
function weaponCritBonus(){const w=activeWeapon();return (w?.fusion?.crit||0)+([0,.03,.08][w?.custom?.scope||0])}
function weaponRateBonus(){const w=activeWeapon();return (w?.fusion?.rate||0)+([.08,0,-.08][w?.custom?.barrel||0])+([.06,.02,-.02][w?.custom?.stock||0])}
function saveWeapons(){localStorage.setItem('barrel-weapons-v1',JSON.stringify({inventory,equippedId,crates:weaponCrates}))}
function crateCost(){return Math.round(140*Math.pow(1.4,weaponCrates))}
const scene=new THREE.Scene();scene.background=new THREE.Color('#87c6f4');scene.fog=new THREE.FogExp2('#a8d9ed',.018);
const camera=new THREE.PerspectiveCamera(52,innerWidth/innerHeight,.1,150);camera.position.set(0,9,15);camera.lookAt(0,0,-10);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;$('game').appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0xf3faff,0x5b8d65,2.3));const sun=new THREE.DirectionalLight(0xffedc8,2.7);sun.position.set(-8,18,9);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-22;sun.shadow.camera.right=22;sun.shadow.camera.top=25;sun.shadow.camera.bottom=-25;scene.add(sun);
const mat=(c:number,metal=0)=>new THREE.MeshStandardMaterial({color:c,roughness:.63,metalness:metal});const roadmat=mat(0x596b78),grass=mat(0x50a76b),edge=mat(0xe8c98e),gold=mat(0xffd257,.55),dark=mat(0x24354b),blue=mat(0x3e9dff,.4),red=mat(0xf64d62),wood=mat(0xb86b42),leaf=mat(0x3e9e6c);
function box(w:number,h:number,d:number,m:THREE.Material,x=0,y=0,z=0){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;scene.add(o);return o}
box(14,.15,140,grass,0,-.18,-34);box(7,.16,140,roadmat,0,-.06,-34);for(const x of [-3.65,3.65])box(.22,.25,140,edge,x,.05,-34);
// Road markings and decorative lane studs
const markings:THREE.Mesh[]=[];
for(let i=0;i<22;i++){const m=box(.09,.018,2.3,mat(0xffe8b4),0,.035,-i*6+15);markings.push(m)}
// Stylized roadside scenery: layered canopies, stones and glowing roadside lamps.
const rockMat=mat(0x8a9c9e),bushMat=mat(0x2b995c),bushBright=mat(0x68bd70);
const scenery=new THREE.Group();scene.add(scenery);
for(let i=0;i<44;i++){
 const side=i%2?1:-1,z=12-i*3.2,x=side*(4.6+(i%4)*.72);
 const shrub=new THREE.Mesh(new THREE.IcosahedronGeometry(.45+(i%3)*.15,1),i%3?bushMat:bushBright);
 shrub.position.set(x,.35,z);shrub.scale.set(1.3,.7,1);scenery.add(shrub);
 if(i%4===0){const stone=new THREE.Mesh(new THREE.DodecahedronGeometry(.34+(i%3)*.1,0),rockMat);stone.position.set(x+side*.65,.12,z-1.2);stone.scale.y=.6;scenery.add(stone)}
}
const deco:THREE.Group[]=[];for(let i=0;i<36;i++){const g=new THREE.Group(),x=(i%2?1:-1)*(5+Math.random()*1.5);g.position.set(x,0,-i*4+13);const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.12,.2,1.1,6),wood);trunk.position.y=.55;g.add(trunk);const crown=new THREE.Mesh(new THREE.ConeGeometry(.75,2.2,7),leaf);crown.position.y=2.05;g.add(crown);const crown2=new THREE.Mesh(new THREE.ConeGeometry(.6,1.6,7),i%3?leaf:bushBright);crown2.position.y=2.85;g.add(crown2);scene.add(g);deco.push(g)}
// v0.8: layered roadside world, neon signposts, distant cliffs and instanced flowers.
const cliffMaterials=[mat(0x688c91),mat(0x809e9d),mat(0x9cb1a2)];
for(let i=0;i<22;i++){
 const side=i%2?1:-1,z=9-i*6.5,x=side*(9.5+(i%4)*1.8);
 const cliff=new THREE.Mesh(new THREE.DodecahedronGeometry(2.5+(i%4)*.65,1),cliffMaterials[i%3]);
 cliff.position.set(x,.3,z);cliff.scale.set(1.4,1.5+(i%3)*.45,1.1);cliff.receiveShadow=true;scenery.add(cliff);
}
const flowerGeometry=new THREE.IcosahedronGeometry(.085,0);
const flowerMaterials=[mat(0xffda69),mat(0xff8b9f),mat(0xe8f7fc)];
for(let j=0;j<3;j++){
 const flowers=new THREE.InstancedMesh(flowerGeometry,flowerMaterials[j],90);
 const dummy=new THREE.Object3D();
 for(let i=0;i<90;i++){
  const side=i%2?1:-1;dummy.position.set(side*(4.1+(i*17%51)/10),.13,-(i*19%132)+12);
  dummy.scale.setScalar(.7+(i%5)*.14);dummy.updateMatrix();flowers.setMatrixAt(i,dummy.matrix);
 }
 flowers.instanceMatrix.needsUpdate=true;scenery.add(flowers);
}
const neon=mat(0x26d8ff,.3);const stripeMat=new THREE.MeshStandardMaterial({color:0xffc55d,emissive:0x8a4108,emissiveIntensity:.4,roughness:.45});
for(let i=0;i<12;i++){
 const side=i%2?1:-1,z=10-i*11.5,x=side*3.93;
 const post=new THREE.Mesh(new THREE.BoxGeometry(.12,.78,.13),dark);post.position.set(x,.4,z);scenery.add(post);
 const lamp=new THREE.Mesh(new THREE.BoxGeometry(.18,.18,.2),i%3===0?neon:stripeMat);lamp.position.set(x,.84,z);scenery.add(lamp);
}
// Character accessories and a floating shadow
const player=new THREE.Group();const body=new THREE.Mesh(new THREE.CapsuleGeometry(.43,.9,5,10),blue);body.position.y=1.4;body.castShadow=true;player.add(body);const head=new THREE.Mesh(new THREE.SphereGeometry(.31,14,12),mat(0xf4c39d));head.position.y=2.45;player.add(head);const gun=new THREE.Mesh(new THREE.BoxGeometry(.23,.24,1.1),dark);gun.position.set(.35,1.7,-.58);player.add(gun);const legs=[];for(const x of [-.23,.23]){const l=new THREE.Mesh(new THREE.BoxGeometry(.25,.85,.3),dark);l.position.set(x,.45,0);player.add(l);legs.push(l)}const hair=new THREE.Mesh(new THREE.SphereGeometry(.325,12,10),mat(0x2a2636));hair.scale.set(1,.48,1);hair.position.set(0,2.63,.035);player.add(hair);
// Armored vest and shoulder pads for a more distinctive player silhouette.
const armorVest=new THREE.Mesh(new THREE.BoxGeometry(.83,.68,.48),mat(0x24354c,.45));armorVest.position.set(0,1.48,-.09);player.add(armorVest);
const vestStripe=new THREE.Mesh(new THREE.BoxGeometry(.65,.1,.03),mat(0xf26b4b,.35));vestStripe.position.set(0,1.56,-.35);player.add(vestStripe);
for(const side of [-1,1]){const shoulder=new THREE.Mesh(new THREE.SphereGeometry(.26,10,8),mat(0x374c61,.45));shoulder.position.set(side*.51,1.88,-.03);shoulder.scale.set(1,.65,1.1);player.add(shoulder)}
const visor=new THREE.Mesh(new THREE.BoxGeometry(.57,.13,.16),mat(0x172d46,.5));visor.position.set(0,2.47,-.23);player.add(visor);
const muzzle=new THREE.PointLight(0xffd38a,0,3);muzzle.position.set(.35,1.72,-1.2);player.add(muzzle);
// Layered tactical armor, backpack, gloves and boots, built from low-poly geometry.
const armorTrim=mat(0xf6a44e,.4),armorPanel=mat(0x172a3b,.5),gloveMat=mat(0x152536,.25);
const backpack=new THREE.Mesh(new THREE.BoxGeometry(.73,.9,.38),armorPanel);backpack.position.set(0,1.43,.42);player.add(backpack);
for(const side of [-1,1]){
 const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.145,.57,4,8),mat(0x41566b,.35));arm.position.set(side*.62,1.43,-.16);arm.rotation.z=side*.2;player.add(arm);
 const glove=new THREE.Mesh(new THREE.BoxGeometry(.25,.24,.29),gloveMat);glove.position.set(side*.7,1.07,-.25);player.add(glove);
 const boot=new THREE.Mesh(new THREE.BoxGeometry(.33,.27,.51),armorPanel);boot.position.set(side*.23,.16,-.14);player.add(boot);
 const knee=new THREE.Mesh(new THREE.BoxGeometry(.31,.22,.12),armorTrim);knee.position.set(side*.23,.58,-.19);player.add(knee);
 const buckle=new THREE.Mesh(new THREE.BoxGeometry(.18,.1,.07),armorTrim);buckle.position.set(side*.19,1.25,-.36);player.add(buckle);
}
const helmet=new THREE.Mesh(new THREE.SphereGeometry(.36,12,10,0,Math.PI*2,0,Math.PI*.53),armorPanel);helmet.position.set(0,2.51,0);player.add(helmet);
const visorGlow=new THREE.Mesh(new THREE.BoxGeometry(.48,.055,.035),new THREE.MeshStandardMaterial({color:0x55ecff,emissive:0x17a9db,emissiveIntensity:1.6}));visorGlow.position.set(0,2.47,-.325);player.add(visorGlow);
scene.add(player);player.position.z=5;
// v0.9: optional genuine GLB character with skeletal animations.
// If no licensed asset is installed, the procedural armored soldier remains playable.
const mixerClock=new THREE.Clock();
let soldierMixer:THREE.AnimationMixer|null=null;
let importedSoldier:THREE.Group|null=null;
const gltfLoader=new GLTFLoader();
const soldierUrl=import.meta.env.BASE_URL+'models/soldier.glb';
gltfLoader.load(soldierUrl,(gltf)=>{
 const model=gltf.scene;
 model.scale.setScalar(1.7);
 model.rotation.y=Math.PI;
 model.traverse(o=>{if(o instanceof THREE.Mesh){o.castShadow=true;o.receiveShadow=true}});
 player.add(model);importedSoldier=model;
 // The gun stays visible; procedural body is hidden only when a model loads successfully.
 [body,head,hair,armorVest,vestStripe,visor,helmet,visorGlow,backpack,...legs].forEach(m=>m.visible=false);
 if(gltf.animations.length){soldierMixer=new THREE.AnimationMixer(model);
 const run=gltf.animations.find(a=>/run|walk|idle/i.test(a.name))||gltf.animations[0];
 soldierMixer.clipAction(run).play();}
},undefined,()=>{/* Missing optional GLB: keep the procedural character. */});
// Floating fireflies and a richer physical sky/lighting treatment.
const glowMaterial=new THREE.MeshBasicMaterial({color:0xffe79c,transparent:true,opacity:.8,depthWrite:false});
const motes:THREE.Mesh[]=[];
for(let i=0;i<30;i++){
 const mote=new THREE.Mesh(new THREE.SphereGeometry(.045,6,5),glowMaterial);
 mote.position.set((i%2?1:-1)*(3.9+(i*7%31)/10),.45+(i%9)*.28,10-(i*13%90));
 scene.add(mote);motes.push(mote);
}
const rim=new THREE.DirectionalLight(0x69c9ff,1.5);rim.position.set(7,7,-9);scene.add(rim);

function updateGun(){const w=activeWeapon(),tier=w?.tier||0;(gun.material as THREE.MeshStandardMaterial).color.setHex(w?.fusion?0x40f0db:weaponColors[tier]);gun.scale.set(1+.09*tier,1+.09*tier,1+.17*tier)}
updateGun();
// Procedural 3D weapon builder: visible on the character and in the armory preview.
type PartKey='barrel'|'stock'|'scope'|'glow';
const partLabels:Record<PartKey,string[]>={barrel:['Короткий','Длинный','Тяжёлый'],stock:['Компактный','Тактический','Усиленный'],scope:['Без прицела','Коллиматор','Оптика'],glow:['Бирюзовый','Золотой','Фиолетовый']};
const partColors=[0x45f4d3,0xffc76d,0xbb83ff];
const gunAssembly=new THREE.Group();player.add(gunAssembly);gun.visible=false;
function makePart(geo:THREE.BufferGeometry,material:THREE.Material,x:number,y:number,z:number,parent:THREE.Group){const mesh=new THREE.Mesh(geo,material);mesh.position.set(x,y,z);mesh.castShadow=true;parent.add(mesh);return mesh}
function buildWeaponModel(w:Weapon){const group=new THREE.Group();const c=w.custom||{barrel:0,stock:0,scope:0,glow:0};const accent=mat(partColors[c.glow],.48),steel=mat(0x263447,.7),trim=mat(0x9fb4c8,.65);const size=1+(w.tier*.045);group.scale.setScalar(size);
// v1.1: layered receiver, heat shield, vented barrel and mechanical accents.
makePart(new THREE.BoxGeometry(.27,.27,.78),steel,0,0,0,group);
const edge=mat(0x60788a,.36), grip=mat(0x111d2a,.95), luminous=new THREE.MeshStandardMaterial({color:partColors[c.glow],emissive:partColors[c.glow],emissiveIntensity:1.3,metalness:.45,roughness:.26});
makePart(new THREE.BoxGeometry(.285,.055,.68),edge,0,.115,-.025,group);
makePart(new THREE.BoxGeometry(.295,.045,.35),grip,0,-.145,-.20,group);
for(let i=0;i<5;i++){
 const vent=makePart(new THREE.BoxGeometry(.017,.045,.055),luminous,.148,.042,-.33+i*.115,group);
 vent.rotation.x=.12;
 makePart(new THREE.BoxGeometry(.017,.045,.055),luminous,-.148,.042,-.33+i*.115,group);
}
makePart(new THREE.BoxGeometry(.18,.055,.12),edge,0,.205,.19,group);
makePart(new THREE.BoxGeometry(.21,.24,.075),grip,0,-.27,-.14,group).rotation.x=-.19;
makePart(new THREE.BoxGeometry(.085,.14,.19),edge,.12,-.21,.10,group);

makePart(new THREE.BoxGeometry(.31,.08,.34),accent,0,.15,-.13,group);
makePart(new THREE.BoxGeometry(.12,.39,.18),steel,0,-.28,.12,group).rotation.x=-.25;
const length=[.55,.85,1.12][c.barrel];makePart(new THREE.CylinderGeometry(c.barrel===2?.105:.065,c.barrel===2?.105:.065,length,10),trim,0,.015,-.44-length/2,group).rotation.x=Math.PI/2;
makePart(new THREE.CylinderGeometry(.115,.115,.12,12),accent,0,.015,-.44-length,group).rotation.x=Math.PI/2;
for(let i=0;i<3;i++){
 const z=-.48-length*(.22+i*.22);
 makePart(new THREE.BoxGeometry(.22,.035,.045),grip,0,.115,z,group);
}
makePart(new THREE.BoxGeometry(.09,.035,.32),luminous,0,-.13,-.39,group);

makePart(new THREE.BoxGeometry(c.stock===2?.38:.25,.21,c.stock===0?.33:.65),steel,0,-.02,.53,group);
if(c.stock===2)makePart(new THREE.BoxGeometry(.39,.09,.15),accent,0,-.12,.78,group);
if(c.scope>0){makePart(new THREE.BoxGeometry(.12,.14,.19),trim,0,.25,-.03,group);const optic=makePart(new THREE.CylinderGeometry(c.scope===2?.16:.11,c.scope===2?.16:.11,c.scope===2?.42:.2,12),steel,0,.37,-.03,group);optic.rotation.x=Math.PI/2;makePart(new THREE.CircleGeometry(c.scope===2?.11:.075,14),accent,0,.37,-.25,group)}
return group}
function clearGroup(g:THREE.Group){for(const child of [...g.children]){g.remove(child);child.traverse(o=>{if(o instanceof THREE.Mesh){o.geometry.dispose();const mats=Array.isArray(o.material)?o.material:[o.material];mats.forEach(m=>m.dispose())}})}}
function refreshGunAssembly(){clearGroup(gunAssembly);const w=activeWeapon();if(!w)return;const model=buildWeaponModel(w);model.position.set(.35,1.72,-.55);gunAssembly.add(model)}
refreshGunAssembly();
// Additional articulated detail: a pair of animated forearms, gait and recoil.
const armatures=player.children.filter((o):o is THREE.Mesh=>o instanceof THREE.Mesh && o.geometry instanceof THREE.CapsuleGeometry && o!==body);
let recoil=0;
const previewScene=new THREE.Scene();previewScene.background=new THREE.Color('#0b1a2b');const previewCamera=new THREE.PerspectiveCamera(42,1,.1,30);previewCamera.position.set(2.3,1.5,3.6);previewCamera.lookAt(0,0,0);previewScene.add(new THREE.HemisphereLight(0xffffff,0x506d98,3));const previewLight=new THREE.DirectionalLight(0xffe3b1,3);previewLight.position.set(-2,4,3);previewScene.add(previewLight);const fillLight=new THREE.PointLight(0x44e7ff,18,6);fillLight.position.set(2,1,-2);previewScene.add(fillLight);const previewRenderer=new THREE.WebGLRenderer({antialias:true,alpha:false});previewRenderer.setPixelRatio(Math.min(devicePixelRatio,1.5));previewRenderer.setSize(300,220);$('weaponPreview').appendChild(previewRenderer.domElement);let previewModel:THREE.Group|null=null;
function refreshPreview(){if(previewModel){previewScene.remove(previewModel);clearGroup(previewModel)}const w=activeWeapon();if(w){previewModel=buildWeaponModel(w);previewScene.add(previewModel)}}
refreshPreview();
function customizeWeapon(k:PartKey,value:number){const w=activeWeapon();if(!w)return;w.custom={barrel:0,stock:0,scope:0,glow:0,...w.custom,[k]:value};saveWeapons();refreshGunAssembly();refreshPreview();renderCustomizer();toast('ДЕТАЛЬ УСТАНОВЛЕНА • ХАРАКТЕРИСТИКИ ОБНОВЛЕНЫ')}
function renderCustomizer(){const w=activeWeapon();if(!w)return;const root=$('customParts');root.replaceChildren();for(const key of ['barrel','stock','scope','glow'] as PartKey[]){const section=document.createElement('div');section.className='partSection';const heading=document.createElement('strong');heading.textContent=({barrel:'Ствол',stock:'Приклад',scope:'Прицел',glow:'Цвет подсветки'} as Record<PartKey,string>)[key];section.append(heading);const options=document.createElement('div');options.className='partOptions';partLabels[key].forEach((name,i)=>{const button=document.createElement('button');button.className='partChoice'+((w.custom?.[key]||0)===i?' selected':'');button.textContent=name;button.onclick=()=>customizeWeapon(key,i);options.append(button)});section.append(options);root.append(section)}}
// v1.0: biome palettes change as the player progresses, without loading heavy textures.
const biomes=[
 {name:'ЗЕЛЁНАЯ ДОЛИНА',sky:0x87c6f4,fog:0xa8d9ed,grass:0x50a76b,road:0x596b78,leaves:0x3e9e6c},
 {name:'ПЕСЧАНЫЙ КАНЬОН',sky:0xf9c58e,fog:0xf4c69a,grass:0xc69a59,road:0x89796a,leaves:0x8eae64},
 {name:'ЛЕДЯНОЙ ПЕРЕВАЛ',sky:0xa6d6fa,fog:0xd4e9f7,grass:0xd1e3e8,road:0x788d9d,leaves:0x8bb7b6},
 {name:'НЕОНОВЫЙ ГОРОД',sky:0x211b48,fog:0x493675,grass:0x30375d,road:0x292f49,leaves:0x9a55d7}
];
let biomeIndex=-1;
function applyBiome(){const index=Math.floor((state.stage-1)/4)%biomes.length;if(index===biomeIndex)return;biomeIndex=index;const b=biomes[index];scene.background=new THREE.Color(b.sky);(scene.fog as THREE.FogExp2).color.setHex(b.fog);grass.color.setHex(b.grass);roadmat.color.setHex(b.road);leaf.color.setHex(b.leaves);bushMat.color.setHex(b.leaves);$('biomeName').textContent=b.name;toast('НОВАЯ ЛОКАЦИЯ: '+b.name)}
// Short-lived translucent shockwaves make barrel destruction visible in 3D.
const shockwaves:{mesh:THREE.Mesh;life:number}[]=[];
function shockwave(x:number,z:number,boss:boolean){const mesh=new THREE.Mesh(new THREE.RingGeometry(.35,.5,32),new THREE.MeshBasicMaterial({color:boss?0xff6688:0xffe6a1,transparent:true,opacity:.85,depthWrite:false,side:THREE.DoubleSide}));mesh.rotation.x=-Math.PI/2;mesh.position.set(x,.12,z);scene.add(mesh);shockwaves.push({mesh,life:.48})}
const flashMaterial=new THREE.MeshBasicMaterial({color:0xffefad,transparent:true,opacity:.9,depthWrite:false});
const flash=new THREE.Mesh(new THREE.SphereGeometry(.22,10,8),flashMaterial);flash.position.set(.35,1.72,-1.3);player.add(flash);flash.visible=false;
const barrels:{group:THREE.Group;hp:number;max:number;label:THREE.Sprite;kind:number;boss:boolean}[]=[];
function label(text:string){const c=document.createElement('canvas');c.width=256;c.height=128;const ctx=c.getContext('2d')!;ctx.font='900 85px system-ui';ctx.textAlign='center';ctx.lineWidth=10;ctx.strokeStyle='#1c2b35';ctx.strokeText(text,128,91);ctx.fillStyle='white';ctx.fillText(text,128,91);const t=new THREE.CanvasTexture(c);const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true,depthTest:false}));s.scale.set(1.6,.8,1);return s}
function spawn(z:number){const g=new THREE.Group(),kind=Math.random();const boss=state.kills>0&&state.kills%18===0&&!barrels.some(b=>b.boss);const hp=Math.round((boss?350:kind>.9?80:kind>.55?30:10)*(1+state.stage*.27));const barrel=new THREE.Mesh(new THREE.CylinderGeometry(boss?1.05:.67,boss?1.05:.67,boss?1.65:1.2,18),boss?red:kind>.9?gold:kind>.55?blue:wood);barrel.rotation.z=Math.PI/2;barrel.position.y=.75;barrel.castShadow=true;g.add(barrel);for(const zz of [-.46,.46]){const ring=new THREE.Mesh(new THREE.TorusGeometry(boss?1.05:.66,.075,6,18),dark);ring.rotation.y=Math.PI/2;ring.position.set(zz,.75,0);g.add(ring)}// Reinforced endcaps, contrasting metal seams and a luminous rarity badge.
const rimMat=boss?mat(0xffb4a0,.7):mat(0xb8c8d1,.72);
for(const side of [-1,1]){
 const cap=new THREE.Mesh(new THREE.CylinderGeometry(boss?1.055:.685,boss?1.055:.685,.095,20),rimMat);
 cap.rotation.z=Math.PI/2;cap.position.set(side*(boss?.82:.6),.75,0);g.add(cap);
}
const emblem=new THREE.Mesh(new THREE.OctahedronGeometry(boss?.27:.19,0),new THREE.MeshStandardMaterial({color:boss?0xff3f5e:kind>.9?0xffda66:kind>.55?0x46c9ff:0x89e6a3,emissive:boss?0xdd143a:0x236b69,emissiveIntensity:.85,metalness:.3}));emblem.position.set(0,1.45,-.64);g.add(emblem);
const txt=label(String(hp));txt.position.y=1.85;g.add(txt);g.position.set(boss?0:(Math.floor(Math.random()*3)-1)*2.05,0,z);scene.add(g);barrels.push({group:g,hp,max:hp,label:txt,kind:boss?8:kind>.9?3:kind>.55?2:1,boss})}
for(let i=0;i<9;i++)spawn(-i*8-13);
const shots:{mesh:THREE.Mesh;target:THREE.Group;damage:number}[]=[];const particles:{mesh:THREE.Mesh;vx:number;vy:number;vz:number;life:number}[]=[];
const bulletMat=new THREE.MeshBasicMaterial({color:0xffe987});function shoot(bonus=0){const b=barrels.filter(b=>b.group.position.z<player.position.z-1).sort((a,b)=>b.group.position.z-a.group.position.z)[0];if(!b)return;const p=new THREE.Mesh(new THREE.SphereGeometry(.11,8,8),bulletMat);p.position.set(player.position.x+.35,1.7,4.3);scene.add(p);shots.push({mesh:p,target:b.group,damage:Math.ceil((state.damage+bonus)*weaponMultiplier())*(Math.random()<Math.min(.85,state.crit*.04+weaponCritBonus())?2:1)});muzzle.intensity=3;flash.visible=true;recoil=Math.min(.16,recoil+.07);flash.scale.setScalar(.8+Math.random()*.6);}
function burst(x:number,z:number,count:number){for(let i=0;i<count;i++){const p=new THREE.Mesh(new THREE.BoxGeometry(.1,.1,.1),i%2?gold:wood);p.position.set(x,.9,z);scene.add(p);particles.push({mesh:p,vx:(Math.random()-.5)*7,vy:Math.random()*5,vz:(Math.random()-.5)*7,life:.7+Math.random()*.3})}}
function toast(t:string){$('toast').textContent=t;$('toast').style.opacity='1';setTimeout(()=>$('toast').style.opacity='0',650)}
type ShopKey='damage'|'rate'|'income'|'crit'|'multishot'|'armor'|'luck';
const shopDefs:{key:ShopKey;name:string;desc:string;base:number;growth:number;max:number}[]=[
{key:'damage',name:'🎯 Мощность',desc:'+1 к урону каждого попадания',base:20,growth:1.42,max:100},
{key:'rate',name:'⚡ Скорострельность',desc:'Больше автоматических выстрелов',base:40,growth:1.65,max:15},
{key:'income',name:'🪙 Доход',desc:'Больше монет за уничтожение бочек',base:60,growth:1.5,max:50},
{key:'crit',name:'💥 Критический удар',desc:'+4% шанса двойного урона (до 60%)',base:100,growth:1.8,max:15},
{key:'multishot',name:'🔫 Двойной выстрел',desc:'+1 дополнительная пуля за залп (до 3)',base:250,growth:3,max:3},
{key:'armor',name:'🛡️ Броня',desc:'+1 максимальное здоровье и лечение',base:120,growth:1.75,max:10},
{key:'luck',name:'🍀 Удача',desc:'+10% к награде за бочки',base:90,growth:1.65,max:20}
];
function shopLevel(k:ShopKey){return ['damage','rate','income'].includes(k)?state[k]-1:state[k]}
function shopCost(d:typeof shopDefs[number]){return Math.round(d.base*Math.pow(d.growth,shopLevel(d.key)))}
function renderShop(){const root=$('shopItems');$('shopCoins').textContent=String(state.coins);root.replaceChildren();for(const d of shopDefs){const lvl=shopLevel(d.key),maxed=lvl>=d.max,cost=shopCost(d);const item=document.createElement('div');item.className='shopItem';const info=document.createElement('div');info.className='shopInfo';const name=document.createElement('div');name.className='shopName';name.textContent=d.name;const desc=document.createElement('div');desc.className='shopDesc';desc.textContent=d.desc;const level=document.createElement('div');level.className='shopLevel';level.textContent=`Уровень ${lvl} / ${d.max}`;info.append(name,desc,level);const button=document.createElement('button');button.className='shopBuy';button.textContent=maxed?'МАКС':`🪙 ${cost}`;button.disabled=maxed||state.coins<cost;button.onclick=()=>purchase(d.key);item.append(info,button);root.append(item)}}
function purchase(k:ShopKey){const d=shopDefs.find(x=>x.key===k)!;if(shopLevel(k)>=d.max)return;const cost=shopCost(d);if(state.coins<cost){toast('Недостаточно монет');return}state.coins-=cost;state[k]++;if(k==='armor')state.hp=Math.min(5+state.armor,state.hp+1);toast('УЛУЧШЕНО!');save();ui();renderShop()}
function toggleShop(open:boolean){$('shopOverlay').classList.toggle('open',open);if(open)renderShop()}
let fusionSelection:number|null=null;
function fuseWeapons(aId:number,bId:number){const a=inventory.find(w=>w.id===aId),b=inventory.find(w=>w.id===bId);if(!a||!b||a.id===b.id||a.fusion||b.fusion||a.tier===b.tier)return false;if(characterLevel()<FUSION_UNLOCK_LEVEL){toast(`Нужен уровень ${FUSION_UNLOCK_LEVEL}`);return false}const cost=fusionCost(a,b);if(state.coins<cost){toast('Недостаточно монет');return false}state.coins-=cost;const lo=Math.min(a.tier,b.tier),hi=Math.max(a.tier,b.tier);const power=Number((Math.pow(1.7,hi)*(1.28+0.08*(hi-lo))).toFixed(3));a.tier=hi;a.fusion={a:lo,b:hi,name:customName(lo,hi),power,crit:Number((.03+.01*lo).toFixed(2)),rate:Number((.04+.015*hi).toFixed(3))};inventory=inventory.filter(w=>w.id!==b.id);if(equippedId===b.id)equippedId=a.id;fusionSelection=null;updateGun();refreshGunAssembly();refreshPreview();renderCustomizer();saveWeapons();save();renderWeapons();ui();toast('СОЗДАНО КАСТОМНОЕ ОРУЖИЕ!');return true}
function renderWeapons(){const root=$('weaponItems');root.replaceChildren();$('weaponCoins').textContent=String(state.coins);$('weaponCost').textContent='🪙 '+crateCost();($('weaponBuy') as HTMLButtonElement).disabled=state.coins<crateCost()||inventory.length>=24;
$('weaponCount').textContent=inventory.length+'/24';$('weaponPower').textContent='×'+weaponMultiplier().toFixed(2);const fusionInfo=$('fusionInfo');fusionInfo.textContent=characterLevel()<FUSION_UNLOCK_LEVEL?`🔒 Гибридная кузница откроется на уровне ${FUSION_UNLOCK_LEVEL}. Сейчас: ${characterLevel()}.`:`⚗️ Гибридная кузница открыта! Выбери две разные обычные пушки. Цена зависит от их редкости.`;
for(const w of inventory){const card=document.createElement('div');card.className='weaponCard';const title=document.createElement('div');title.className='weaponTitle';title.textContent='🔫 '+(w.fusion?'✨ '+w.fusion.name:weaponNames[w.tier]);title.style.color='#'+weaponColors[w.tier].toString(16).padStart(6,'0');const desc=document.createElement('div');desc.className='shopDesc';desc.textContent=w.fusion?`КАСТОМ • урон ×${w.fusion.power.toFixed(2)} • крит +${Math.round(w.fusion.crit*100)}% • скорость +${Math.round(w.fusion.rate*100)}%`:'Уровень '+(w.tier+1)+' • урон ×'+Math.pow(1.7,w.tier).toFixed(2);const equip=document.createElement('button');equip.className='weaponAction';equip.textContent=w.id===equippedId?'✓ Выбрано':'Выбрать';equip.disabled=w.id===equippedId;equip.onclick=()=>{equippedId=w.id;updateGun();refreshGunAssembly();refreshPreview();renderCustomizer();saveWeapons();renderWeapons();toast('ОРУЖИЕ ВЫБРАНО')};const pair=inventory.find(x=>x.id!==w.id&&x.tier===w.tier&&!x.fusion);const compatible=inventory.find(x=>x.id!==w.id&&!x.fusion&&x.tier!==w.tier);const merge=document.createElement('button');merge.className='weaponAction merge';merge.textContent=w.tier===5?'МАКС':pair?'⬆ Объединить':'Нужна копия';merge.disabled=!pair||w.tier===5||!!w.fusion;merge.onclick=()=>{if(!pair)return;inventory=inventory.filter(x=>x.id!==pair.id);w.tier++;if(equippedId===pair.id)equippedId=w.id;updateGun();refreshGunAssembly();refreshPreview();renderCustomizer();saveWeapons();renderWeapons();toast('НОВОЕ ОРУЖИЕ!')};const fuse=document.createElement('button');fuse.className='weaponAction merge';const selected=inventory.find(x=>x.id===fusionSelection);const valid=!!selected&&selected.id!==w.id&&!selected.fusion&&!w.fusion&&selected.tier!==w.tier;fuse.textContent=characterLevel()<FUSION_UNLOCK_LEVEL?'🔒 Ур. 10':valid?`⚗️ Создать 🪙 ${fusionCost(selected!,w)}`:fusionSelection===w.id?'✓ Первый компонент': '⚗️ Гибрид';fuse.disabled=characterLevel()<FUSION_UNLOCK_LEVEL||!!w.fusion||(!valid&&!compatible&&!selected)|| (valid&&state.coins<fusionCost(selected!,w));fuse.onclick=()=>{if(valid){fuseWeapons(selected!.id,w.id)}else{fusionSelection=fusionSelection===w.id?null:w.id;renderWeapons()}};card.append(title,desc,equip,merge,fuse);root.append(card)}}
function toggleWeapons(open:boolean){$('weaponOverlay').classList.toggle('open',open);if(open){renderWeapons();renderCustomizer();refreshPreview()}}
$('weaponOpen').onclick=()=>toggleWeapons(true);$('weaponClose').onclick=()=>toggleWeapons(false);
$('weaponOverlay').addEventListener('click',e=>{if(e.target===$('weaponOverlay'))toggleWeapons(false)});
$('weaponBuy').onclick=()=>{const cost=crateCost();if(state.coins<cost||inventory.length>=24)return;state.coins-=cost;weaponCrates++;const tier=Math.random()<.06?2:Math.random()<.23?1:0;const w={id:nextWeaponId++,tier};inventory.push(w);save();saveWeapons();renderWeapons();ui();toast('ПОЛУЧЕНО: '+weaponNames[tier])};
$('shopOpen').onclick=()=>toggleShop(true);$('shopClose').onclick=()=>toggleShop(false);
$('shopOverlay').addEventListener('click',e=>{if(e.target===$('shopOverlay'))toggleShop(false)});
addEventListener('keydown',e=>{if(e.key==='Escape'){toggleShop(false);toggleWeapons(false)}});
function save(){localStorage.setItem('barrel-save',JSON.stringify(state))}function ui(){for(const k of ['coins','score','stage','hp'])$(k).textContent=String((state as any)[k]);$('dmg').textContent=String(state.damage);$('combo').textContent=String(state.combo);$('characterLevel').textContent=String(characterLevel());$('costDmg').textContent='🪙 '+shopCost(shopDefs[0]);$('costRate').textContent='🪙 '+shopCost(shopDefs[1]);$('costCoins').textContent='🪙 '+shopCost(shopDefs[2]);for(const [id,k] of [['upDmg','damage'],['upRate','rate'],['upCoins','income']] as const){const d=shopDefs.find(d=>d.key===k)!;($(id) as HTMLButtonElement).disabled=shopLevel(k)>=d.max||state.coins<shopCost(d)}}
function buy(k:'damage'|'rate'|'income',_base:number){purchase(k)}
$('upDmg').onclick=()=>buy('damage',20);$('upRate').onclick=()=>buy('rate',40);$('upCoins').onclick=()=>buy('income',60);
let drag=false,px=0;renderer.domElement.addEventListener('pointerdown',e=>{drag=true;px=e.clientX;renderer.domElement.setPointerCapture(e.pointerId);shoot(Math.max(1,Math.ceil(state.damage*.5)))});renderer.domElement.addEventListener('pointermove',e=>{if(!drag)return;player.position.x=THREE.MathUtils.clamp(player.position.x+(e.clientX-px)/innerWidth*9,-2.85,2.85);px=e.clientX});renderer.domElement.addEventListener('pointerup',()=>drag=false);
let last=performance.now(),fire=0,dist=0,hitCooldown=0,comboTimer=0;function tick(now:number){requestAnimationFrame(tick);const dt=Math.min((now-last)/1000,.05);last=now;soldierMixer?.update(mixerClock.getDelta());for(let i=0;i<motes.length;i++){const m=motes[i];m.position.z+=dt*5.5;if(m.position.z>16)m.position.z-=95;m.position.y+=Math.sin(now*.0018+i)*dt*.16}fire+=dt;dist+=dt*5.5;comboTimer-=dt;if(comboTimer<=0)state.combo=0;muzzle.intensity=Math.max(0,muzzle.intensity-dt*24);flash.visible=muzzle.intensity>1.3;applyBiome();for(const m of markings){m.position.z+=dt*5.5;if(m.position.z>17)m.position.z-=132}hitCooldown=Math.max(0,hitCooldown-dt);player.position.y=Math.sin(now*.012)*.07;legs.forEach((l,i)=>l.rotation.x=Math.sin(now*.014+i*Math.PI)*.38);
armatures.forEach((a,i)=>a.rotation.x=Math.sin(now*.014+i*Math.PI)*.13);
recoil=Math.max(0,recoil-dt*.75);
gunAssembly.position.z=recoil;
gunAssembly.rotation.x=Math.sin(now*.009)*.022+recoil*.55;if(fire>Math.max(.11,.57/(state.rate*(1+weaponRateBonus())))){fire=0;for(let i=0;i<1+state.multishot;i++)shoot()}
for(const b of [...barrels]){b.group.position.z+=dt*5.5;b.group.rotation.y+=dt*.25;if(b.group.position.z>7){if(Math.abs(b.group.position.x-player.position.x)<1.2&&hitCooldown===0){state.hp--;state.combo=0;hitCooldown=1;toast('ПОПАДАНИЕ!');if(state.hp<=0){state.hp=5+state.armor;state.coins=Math.max(0,state.coins-20);toast('НОВАЯ ПОПЫТКА')}}scene.remove(b.group);barrels.splice(barrels.indexOf(b),1);spawn(-68-Math.random()*9)}}
for(let i=shots.length-1;i>=0;i--){const s=shots[i],b=barrels.find(b=>b.group===s.target);s.mesh.position.z-=dt*36;if(b&&s.mesh.position.z<=b.group.position.z){b.hp-=s.damage;b.group.scale.setScalar(.92+Math.random()*.08);b.group.remove(b.label);(b.label.material as THREE.SpriteMaterial).map?.dispose();b.label.material.dispose();b.label=label(String(Math.max(0,b.hp)));b.label.position.y=1.85;b.group.add(b.label);burst(b.group.position.x,b.group.position.z,3);if(b.hp<=0){burst(b.group.position.x,b.group.position.z,b.boss?36:18);shockwave(b.group.position.x,b.group.position.z,b.boss);state.combo++;state.kills++;comboTimer=4;const reward=Math.round(b.kind*10*state.income*(1+Math.min(state.combo,20)*.05)*(1+state.luck*.1));state.coins+=reward;state.score+=b.max;toast(b.boss?'БОСС ПОБЕЖДЁН! +'+reward+' 🪙':'+'+reward+' 🪙');scene.remove(b.group);barrels.splice(barrels.indexOf(b),1);spawn(-68-Math.random()*9);if(state.score>state.stage*500){state.stage++;toast('ЭТАП '+state.stage)}save()}scene.remove(s.mesh);s.mesh.geometry.dispose();shots.splice(i,1)}else if(s.mesh.position.z< -80){scene.remove(s.mesh);s.mesh.geometry.dispose();shots.splice(i,1)}}
for(let i=shockwaves.length-1;i>=0;i--){const w=shockwaves[i];w.life-=dt;w.mesh.scale.setScalar(1+(0.48-w.life)*6);(w.mesh.material as THREE.MeshBasicMaterial).opacity=Math.max(0,w.life/.48)*.8;if(w.life<=0){scene.remove(w.mesh);w.mesh.geometry.dispose();(w.mesh.material as THREE.Material).dispose();shockwaves.splice(i,1)}}for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.mesh.position.x+=p.vx*dt;p.mesh.position.y+=p.vy*dt;p.mesh.position.z+=p.vz*dt;p.vy-=dt*13;p.life-=dt;if(p.life<=0){scene.remove(p.mesh);p.mesh.geometry.dispose();particles.splice(i,1)}}for(const d of deco){d.position.z+=dt*5.5;if(d.position.z>18)d.position.z-=144}scenery.position.z=(dist%3.2)ui();renderer.render(scene,camera);if($('weaponOverlay').classList.contains('open')){if(previewModel)previewModel.rotation.y+=dt*.6;previewRenderer.render(previewScene,previewCamera)}}requestAnimationFrame(tick);addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});ui();
