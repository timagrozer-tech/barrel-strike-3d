# Barrel Strike 3D v1.0 — Visual Effects & Biomes

- Four dynamic environment palettes: green valley, desert canyon, snowy pass, neon city; automatically rotate every four stages.
- New muzzle flash and animated barrel-destruction shockwaves.
- Extra destruction debris for boss barrels.
- Weapon idle sway and a location indicator in the HUD.
- Existing weapons, upgrades, forge, customizer and saved progress retained.

## Run
`npm install && npm run dev` for browser development. `npm run build` for production. Android debug APK can be built by the GitHub Actions workflow after pushing this project to GitHub.

**Note:** This is a procedural 3D visual upgrade, not the full fidelity of the promotional concept. Dependencies, runtime and APK build have not been verified in this environment.
